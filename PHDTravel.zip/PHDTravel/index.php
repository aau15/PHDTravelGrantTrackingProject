<html>

<h1>1. Details of Student</h1>



<form method="post" action="stuDetailsTable.php">
	<label>Student Name:<input type="text" name="stuName"></label>
	<br/><br/>
	<label>Email:<input type="text" name="email"></label>
	<br/><br/>
	<label>Date of First Regstration: </label>
	<label>Day<input type="text" name="fRegD"></label>
	<label>Month<input type="text" name="fRegM"></label>
	<label>Year<input type="text" name="fRegY"></label>
	<br/><br/>
	<label>Month Completed:<input type="text" name="monthCom"></label>
	<br/><br/>
	<label>Fees paid by (e.g. DTA, Project(name), Supervisor, Self):<input type="text" name="feePayer"></label>
	<br/><br/>
	<label>Fees last paid: </label>
	<label>Day<input type="text" name="feeLPaidD"></label>
	<label>Month<input type="text" name="feeLPaidM"></label>
	<label>Year<input type="text" name="feeLPaidY"></label>
	<button type="submit" name="submit" style="float:right">submit</button>
</form>	
	<br/><br/>
	<br/><br/>



<h1>2. Details of Trip</h1>
<form method="post" action="tripDetailsTable.php">
	<script> 
	function dis1(){ 
		document.all["purpose"].disabled=true
		document.all["cName"].disabled=false 
		document.all["cURL"].disabled=false 
		document.all["city"].disabled=false 
		document.all["country"].disabled=false 
		document.all["ptitle"].disabled=false 
		document.all["authors"].disabled=false 
	}
	function dis2(){ 
		document.all["purpose"].disabled=false
		document.all["cName"].disabled=true 
		document.all["cURL"].disabled=true 
		document.all["city"].disabled=true 
		document.all["country"].disabled=true 
		document.all["ptitle"].disabled=true 
		document.all["authors"].disabled=true 
	}
	</script> 

	<label><input type="radio" name="check" onclick="dis1()" checked ></label><label>Name of Conference:<input type="text" name="cName"></label>
	<br/><br/>
	<label>Conference URL:<input type="text" name="cURL"></label>
	<br/><br/>
	<label>City:<input type="text" name="city"></label>
	<br/><br/>
	<label>Country:<input type="text" name="country"></label>
	<br/><br/>
	<label>Paper Title:<input type="text" name="ptitle"></label>
	<br/><br/>
	<label>Authors:<input type="text" name="authors"></label>
	<br/><br/>
	<label><input type="radio" name="check" onclick="dis2()"></label><label>Other (Please describe purpose of trip):<input type="text" name="purpose"></label>
	<button type="submit" name="submit" style="float:right">submit</button>
</form>
	
	<br/><br/>
	


<h1>3. Previous Funded Trips</h1>
<table border=1>
<tr>
<td width="5%"></td>  
<td width="20%">Date of Claim (e.g. 21 Jan 2016)</td>       
<td width="25%">Amount Received (Nearest in pound)</td>  
<td width="50%">Conference</td>
<tr>
<td>1</td><td><input type="text" name="dClaim1" style="width:100%;"></td><td><input type="text" name="amR1" style="width:100%;"></td><td><input type="text" name="conference1" style="width:100%;"></td>
<tr>
<td>2</td><td><input type="text" name="dClaim2" style="width:100%;"></td><td><input type="text" name="amR2" style="width:100%;"></td><td><input type="text" name="conference2" style="width:100%;"></td>
<tr>
<td>3</td><td><input type="text" name="dClaim3" style="width:100%;"></td><td><input type="text" name="amR3" style="width:100%;"></td><td><input type="text" name="conference3" style="width:100%;"></td>
<tr>
<td>4</td><td><input type="text" name="dClaim4" style="width:100%;"></td><td><input type="text" name="amR4" style="width:100%;"></td><td><input type="text" name="conference4" style="width:100%;"></td>
</table>
<br/><br/>
<table border=1>
<tr>
<td width="25%">Total funds received (T)</td>  
<td width="25%"><input type="text" name="tFReceived" style="width:100%;"></td>  
<td width="50%">Total Allowance Remaining: 3000-T = <input type="text" name="tARemaining" style="float:right"></td>
<tr>
<td width="25%">Funds received in the last 12 months (Y)</td>  
<td width="25%"><input type="text" name="f12Received" style="width:100%;"></td>       
<td width="50%">12 Month Allowance Remaining: 2000-T = <input type="text" name="tARemaining" style="float:right"></td>  
</table>

<br/><br/>
<br/><br/>

<h1>4. Estimated Cost of Trip</h1>
<form method="post" action="estimatedCostTable.php">
<table border=1>
<tr>
<td width="28%"></td>  
<td width="54%">Calculations & Justification</td>       
<td width="18%">UK Pound</td>  
<tr>
<td>Registration Fee</td>
<td><input type="text" name="rfCal" style="width:100%;"></td><td><input type="text" name="rfECost" style="width:100%;"></td>
<tr>
<td>Transport costs (provide a breakdown)</td>
<td><input type="text" name="tcCal" style="width:100%;"></td><td><input type="text" name="tcECost" style="width:100%;"></td>
<tr>
<td>Accommodation</td>
<td><input type="text" name="aCal" style="width:100%;"></td><td><input type="text" name="aECost" style="width:100%;"></td>
<tr>
<td>Meals</td>
<td><input type="text" name="mCal" style="width:100%;"></td><td><input type="text" name="mECost" style="width:100%;"></td>
<tr>
<td>List other items (if any)</td>
<td><input type="text" name="oCal" style="width:100%;"></td><td><input type="text" name="oECost" style="width:100%;"></td>
<tr>
<td></td><td style="text-align:right;">TOTAL (E)</td>
<td></td>
</table>
<br/><br/>
<button type="submit" name="submit" style="float:right">submit</button>
</form>


<html>

