<?php include("mainPage.html");
?>
<html lang="en">

<head>

</head>

<body>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<form method="post" action="upload.php" enctype="multipart/form-data">
    <table border=0 cellspacing=0 cellpadding=0 align=center width="100%">
        <tr>
            <td width=55 height=20 align="center"><input type="hidden" name="MAX_FILE_SIZE" value="2000000">File : </TD>
            <td height="16">
                <input name="file" type="file"  value="View" >
                <input type="submit" value="Upload" name="Upload">
            </td>
        </tr>
    </table>
</form>
</body>
</html>
