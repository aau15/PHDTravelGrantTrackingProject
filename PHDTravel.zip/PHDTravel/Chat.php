<!DOCTYPE html>
<?php include("mainPage.html");?>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<title>Chats</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
<meta name="description" content="">
<meta name="author" content="">
<!-- STYLESHEETS --><!--[if lt IE 9]><script src="js/flot/excanvas.min.js"></script><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script><![endif]-->
<link rel="stylesheet" type="text/css" href="css/cloud-admin.css" >
<link rel="stylesheet" type="text/css"  href="css/themes/default.css" id="skin-switcher" >
<link rel="stylesheet" type="text/css"  href="css/responsive.css" >

<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
<!-- DATE RANGE PICKER -->
<link rel="stylesheet" type="text/css" href="js/bootstrap-daterangepicker/daterangepicker-bs3.css" />
<!-- ANIMATE -->
<link rel="stylesheet" type="text/css" href="css/animatecss/animate.min.css" />
<!-- FONTS -->




</head>
<body>

<br></br><br></br><br></br>
<!-- PAGE -->
<section id="page">

<!-- /SIDEBAR -->
<div id="main-content">
<!-- SAMPLE BOX CONFIGURATION MODAL FORM-->

<!-- /SAMPLE BOX CONFIGURATION MODAL FORM-->

<!-- /PAGE HEADER -->

<!-- CHAT -->
<div class="row">
<div class="col-md-8 col-md-offset-2">
<!-- BOX -->
<div class="box border green chat-window">
<div class="box-title">
<h4><i class="fa fa-comments"></i>Chat Window</h4>
<div class="tools">

</div>
</div>
<?php
@session_start();
$security_token = $_SESSION['security_token'] = uniqid(rand());
$conn = new mysqli("mysql5006.smarterasp.net", "a117c6_phd", "phd12345");

if ($conn->connect_error) {
	die("Failed " . $conn->connect_error);
}
$user = $_SESSION["stuID"];
$sql = "SELECT * FROM db_a117c6_phd.message WHERE StudentID = '{$_SESSION["stuID"]}'   ORDER BY MessageID ";
$result = $conn->query($sql);	?>
                                <div class="box-body big">
                                    <div class="scroller" data-height="450px" data-always-visible="1" data-rail-visible="1">
                                        <ul class="media-list chat-list">

                                            <?php
									    while($rows=mysqli_fetch_array($result)){


										    $a = $rows["MessageID"];
                                            $TIMESTAMP = $rows["TimeStamp"]; 
                                            $SENDERNAME = $rows["senderName"]; 
                                            if ($SENDERNAME !=$user){ ?>
                                            <li class="media">
                                                <div class="media-body chat-pop">
                                                    <h4 class="media-heading"><?php echo $SENDERNAME ?><span class="pull-right"><i class="fa fa-clock-o"></i> <abbr class="timeago" ><?php echo $TIMESTAMP ?></abbr> </span></h4>
                                                    <?php echo '<p>'.$rows["MessageBody"].'</p>' ?>
                                                </div>
                                                                                                    
                                            </li>
                                            <?php } 
                                            if ($SENDERNAME ==$user){ ?>
                                            <li class="media">
                                                <div class="pull-right media-body chat-pop mod">
                                                    <h4 class="media-heading">You<span class="pull-left"><i class="fa fa-clock-o"></i> <abbr class="timeago" ><?php echo $TIMESTAMP ?></abbr> </span></h4>
                                                    <?php echo '<p>'.$rows["MessageBody"].'</p>' ?>
                                                </div>
                                                                                               
                                            </li>
                                            <?php 
                                                } 
                                             }
                                            $conn->close();
                                            ?>




                                        </ul>
                                    </div>
                                    <div class="divide-20"></div>
                                    <div class="chat-form">
                                        <form method="post"  id="myform" action="MessageSubmit.php" target="myIframe">
                                        <div class="input-group">
                                            <input type="text" class="form-control"  name = "content">
                                            <span class="input-group-btn"> <Button class="btn btn-primary" type="submit" onclick="formSubmit()" ><i class="fa fa-check"></i></Button></span>
                                        </div>
                                            </form>
                                        <iframe name="myIframe" style="display:none"></iframe>
                                    </div>
                                </div>
                            </div>
                            <!-- /BOX -->
                        </div>
                    </div>

<!--                    <form method="post" action="MessageSubmit.php">-->
<!--                        <input type="text"  name="content">-->
<!--                        <input type="submit" name="Submit" value="submit">-->
<!--                        </form>-->

                        <!-- /CHAT -->

                    <div class="footer-tools">
							<span class="go-top">
								<i class="fa fa-chevron-up"></i> Top
							</span>
                    </div>
                </div><!-- /CONTENT-->
            </div>
        </div>
    </div>
</section>
<!--/PAGE -->
<!-- JAVASCRIPTS -->
<!-- Placed at the end of the document so the pages load faster -->
<!-- JQUERY -->
<script src="js/jquery/jquery-2.0.3.min.js"></script>
<!-- JQUERY UI-->
<script src="js/jquery-ui-1.10.3.custom/js/jquery-ui-1.10.3.custom.min.js"></script>
<!-- BOOTSTRAP -->
<script src="bootstrap-dist/js/bootstrap.min.js"></script>


<!-- DATE RANGE PICKER -->
<script src="js/bootstrap-daterangepicker/moment.min.js"></script>

<script src="js/bootstrap-daterangepicker/daterangepicker.min.js"></script>
<!-- SLIMSCROLL -->
<script type="text/javascript" src="js/jQuery-slimScroll-1.3.0/jquery.slimscroll.min.js"></script><script type="text/javascript" src="js/jQuery-slimScroll-1.3.0/slimScrollHorizontal.min.js"></script>
<!-- BLOCK UI -->
<script type="text/javascript" src="js/jQuery-BlockUI/jquery.blockUI.min.js"></script>
<!-- TIMEAGO -->
<script type="text/javascript" src="js/timeago/jquery.timeago.min.js"></script>
<!-- COOKIE -->
<script type="text/javascript" src="js/jQuery-Cookie/jquery.cookie.min.js"></script>
<!-- CUSTOM SCRIPT -->
<script src="js/script.js"></script>
<script>
    jQuery(document).ready(function() {
        App.setPage("chats");  //Set current page
        App.init(); //Initialise plugins and elements
    });
</script>
<script type="text/javascript">
    function formSubmit(){
        document.getElementById('myform').submit();
    }
</script>
<!-- /JAVASCRIPTS -->
</body>
</html>