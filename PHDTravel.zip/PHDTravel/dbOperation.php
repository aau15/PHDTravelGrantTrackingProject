<?php
@session_start();
$security_token = $_SESSION['security_token'] = uniqid(rand());

if (isset($_POST['submit'])){
	
	$tripid = md5($_SESSION["stuID"].date('Y-m-d H:i:s',time()));
	$_SESSION["tripID"] = $tripid;
	$_SESSION["currenttime"] =  date('Y-m-d H:i:s',time());
	$conn = new mysqli('mysql5006.smarterasp.net', 'a117c6_phd', 'phd12345', 'db_a117c6_phd');
	if ($conn -> connect_error) {
		die('Could not connect: ' . $conn -> connect_error);
	}else {
		$_SESSION["status"] = 1;
		 $query_stu = "insert into studenttrip
		(StudentID, TripID, Status)
		values('{$_SESSION["stuID"]}','{$_SESSION["tripID"]}', '{$_SESSION["status"]}')";
		
		$result=$conn->query($query_stu);
		
		$query_trip = "insert into trip
		(TripID, StudentID, ConferenceName, ConferenceURL, City, Country,
		PaperTitle, Author, Purpose, Type, Status, CostOfTrip,SubmissionDate)
		values('{$_SESSION["tripID"]}', '{$_SESSION["stuID"]}',
		'{$_SESSION["cName"]}','{$_SESSION["cURL"]}','{$_SESSION["city"]}','{$_SESSION["country"]}','{$_SESSION["ptitle"]}',
		'{$_SESSION["authors"]}','{$_SESSION["purpose"]}','{$_SESSION["type"]}','{$_SESSION["status"]}','{$_SESSION["totalECost"]}','{$_SESSION["currenttime"]}')";
		
		$result=$conn->query($query_trip);

		$query_ec = "insert into ecost
		(RegFeeCal, RegFee, TransFeeCal, TransFee, AccFeeCal, AccFee, MealFeeCal, MealFee, OtherFeeCal, OtherFee, TripId, TotalECost)
		values('{$_SESSION["rfCal"]}','{$_SESSION["rfCost"]}','{$_SESSION["tcCal"]}','{$_SESSION["tcCost"]}','{$_SESSION["aCal"]}',
		'{$_SESSION["aCost"]}','{$_SESSION["mCal"]}','{$_SESSION["mCost"]}','{$_SESSION["oCal"]}','{$_SESSION["oCost"]}',
		'{$_SESSION["tripID"]}','{$_SESSION["totalECost"]}')";
		
		$result=$conn->query($query_ec);
		
		
		echo "<script>window.location='mainPage.html';</script>";
		
	}
	$conn->close();

	
}