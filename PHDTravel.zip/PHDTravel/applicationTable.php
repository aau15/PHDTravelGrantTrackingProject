<?php include("mainPage.html");
@session_start();
$security_token = $_SESSION['security_token'] = uniqid(rand());
$conn = new mysqli('mysql5006.smarterasp.net', 'a117c6_phd', 'phd12345', 'db_a117c6_phd');

//$StundentID = $_SESSION["StudentID"];

$sql = "SELECT SubmissionDate, amountReceived, ConferenceName FROM trip WHERE  StudentID = '{$_SESSION["stuID"]}' and status = 3";
$result = $conn->query($sql);?>
<html lang="en">

  <head>
		<title>Travel Funding Request Form</title>
		<meta charset="utf-8" />

		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

		<link rel="stylesheet" type="text/css" href="css/style.css">
		
		<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700|Open+Sans:700' rel='stylesheet' type='text/css'>

	
		<script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
		<script src="js/sorting.js" type="text/javascript"></script>
		<script src="js/jquery.isotope.js" type="text/javascript"></script>
	
	
		<style type="text/css">
						table.hovertable {
							font-family: verdana,arial,sans-serif;
							font-size:11px;
							color:#333333;
							width:auto;
							border-width: 1px;
							border-color: #999999;
							border-collapse: collapse;
							margin-left:40px;
						}
						table.hovertable th {
							background-color:#c3dde0;
							border-width: 1px;
							padding: 8px;
							border-style: solid;
							border-color: #fffff2;
						}
						
						table.hovertable tr {
							background-color:#ededed;
						}
						table.hovertable td {
							border-width: 1px;
							padding: 8px;
							border-style: solid;
							border-color: #fffff2;
						}
						
					</style>
	
	</head>
	
	<body>
   <div id="options"  style="background:#34495e;text-align: center;">	
					<ul id="filter" class="option-set" data-option-key="filter">
					
						<li><a class="selected" href="#filter" data-option-value=".studentdetails">Details of Student</a></li>
						<li><a href="#filter" data-option-value=".tripdetails">Details of Trip</a></li>
						<li><a href="#filter" data-option-value=".prefundedtrips">Previous Funded Trips</a></li>
						<li><a href="#filter" data-option-value=".ecosttrip">Estimated Cost of Trip</a></li>
						<li><a href="#filter" data-option-value=".maxclaim">Maximum Allowable Claim</a></li>
					</ul>
				</div><!-- //filter_block -->
		
   <form method="post" action="submitTable.php">
    <!--project start-->    
    <div id="project" style="background:#34495e;z-index:-1">    	

       <div class="container"    style="border-radius:8px; padding-top: 5px;background:#fffff2">
		
		<div class="row">
		<!-- block color change: style.css filter li a.selected  -->
			<!-- filter_block -->
				
		
		
			<div class="portfolio_block columns1   pretty"  data-animated="fadeIn">	
			
			
					<div class="element col-sm-20   studentdetails"  style="padding-bottom:80px">
					
						<div class="col-xs-12 forma">
						<h3>Student Details</h3><br></br>
							<h4>Student name:</h4>
							<input type="text" class="col-md-12 col-xs-12 Subject" name='stuName' placeholder='e.g. tomcat'/><br></br><br></br>
							<h4>Email:</h4>
							<input type="text" class="col-md-12 col-xs-12 Subject" name='email' placeholder='e.g. tomcat@outlook.com'/><br></br><br></br>
							<h4>Date of first regstration:</h4>
							<input type="text" class="col-md-12 col-xs-12 Date1" name='fRegD' placeholder='DD'/>
							<input type="text" class="col-md-12 col-xs-12 Date2" name='fRegM' placeholder='MM'/>
							<input type="text" class="col-md-12 col-xs-12 Date2" name='fRegY' placeholder='YYYY'/><br></br><br></br>
							<h4>Month completed</h4>
							<input type="text" class="col-md-12 col-xs-12 Subject" name='monthCom' placeholder='Month Completed'/><br></br><br></br>
							<h4>Fees paid by:</h4>
							<input type="text" class="col-md-12 col-xs-12 Subject" name='feePayer' placeholder='e.g. DTA, Project(name), Supervisor, Self'/><br></br>	<br></br>
							<h4>Fees last paid:</h4>
							<input type="text" class="col-md-12 col-xs-12 Date1" name='feeLPaidD' placeholder='DD'/>
							<input type="text" class="col-md-12 col-xs-12 Date2" name='feeLPaidM' placeholder='MM'/>
							<input type="text" class="col-md-12 col-xs-12 Date2" name='feeLPaidY' placeholder='YYYY'/>
						
						</div>
					</div>	
					
					<div class="element col-sm-20  gall  tripdetails">
						<div class="col-md-9 col-xs-12 forma">
					
						
						<script> 
							function dis1(){ 
							document.all["purpose"].disabled=true
							document.all["cName"].disabled=false 
							document.all["cURL"].disabled=false 
							document.all["city"].disabled=false 
							document.all["country"].disabled=false 
							document.all["ptitle"].disabled=false 
							document.all["authors"].disabled=false 
						}
						function dis2(){ 
							document.all["purpose"].disabled=false
							document.all["cName"].disabled=true 
							document.all["cURL"].disabled=true 
							document.all["city"].disabled=true 
							document.all["country"].disabled=true 
							document.all["ptitle"].disabled=true 
							document.all["authors"].disabled=true 
						}
						</script> 
						<h3>Trip Details</h3><br></br>
						<label><input type="radio" name="check" onclick="dis1()" checked ></label>
							<h4>Conference name:</h4>
							<input type="text" class="col-md-12 col-xs-12 Subject" name='cName' placeholder='e.g. Database Seminar'/><br></br>
							<h4>Conference URL:</h4>
							<input type="text" class="col-md-12 col-xs-12 Subject" name='cURL' placeholder='e.g. www.db.com'/><br></br>
							<h4>City:</h4>
							<input type="text" class="col-md-12 col-xs-12 Subject" name='city' placeholder='e.g. London'/><br></br>
							<h4>Country:</h4>
							<input type="text" class="col-md-12 col-xs-12 Subject" name='country' placeholder='e.g. UK'/><br></br>
							<h4>Paper title:</h4>
							<input type="text" class="col-md-12 col-xs-12 Subject" name='ptitle' placeholder='e.g. Big data'/><br></br>
							<h4>Authors:</h4>
							<input type="text" class="col-md-12 col-xs-12 Subject" name='authors' placeholder='e.g. Tom'/><br></br>
						<label><input type="radio" name="check" onclick="dis2()"></label>
							<h4>Please describe purpose of trip:</h4><br></br>
							<textarea class="col-md-12 col-xs-12 Message"  name='purpose' placeholder='if others, please describe here'></textarea>
							
						
						</div>
					</div>		
					
					<div class="element col-sm-20   gall prefundedtrips">
					<div class="col-md-9 col-xs-12 forma">
						<h3>Previous Funded Trips</h3>
					</div>
					
					
				
					<br/><br/><br/><br/><br/><br/><br/><br/>
					<table class="hovertable" >
			        <tr>
			  
			            <th></th><th>Date of Claim </th><th>Amount Received (nearest in pound)</th><th>Conference</th>
					
			            <?php
			          
			             $total_cost = 0;
			            $oneyear_cost = 0;
			            $last_date;
			
			            if ($result->num_rows > 0) {
			                $row_num = 0;
			                while($row = $result->fetch_assoc()) {
			                    $row_num ++;
			                    echo "
				
						
							<tr><td>".$row_num ."</td><td>".$row["SubmissionDate"]."</td><td>".$row["amountReceived"]."</td><td>".$row["ConferenceName"]."</td>";
			                    $total_cost += $row["amountReceived"];
			                  
			                }
			               
			            } else {
			                echo "0";
			                $total_cost = 0;
			            }
			            
			            $sql2 = "SELECT SUM(amountReceived) FROM trip WHERE SubmissionDate >=  DATE_ADD(NOW(), INTERVAL -12 month) AND StudentID = '{$_SESSION["stuID"]}' and status = 3";
			            $result = $conn->query($sql2);
			            if($row = mysqli_fetch_array($result))
			            {
			            	$oneyear_cost = $row["SUM(amountReceived)"];
			            }else{
			            	$oneyear_cost = 0;
			            }
			            
			            $conn->close(); 
			            ?>
			    	</table>
			   		<br/><br/><br/><br/>
				    <table class="hovertable" id="oTable">
				        <tr>
				            <th>Total funds received (T)</th><th>Total Allowance Remaining (3000-T)</th>
				             <th>Funds received in the last 12 months (Y)</th><th>12 Month Allowance Remaining (2000-Y)</th>
				            
				        <tr>
				            <td><?php echo $total_cost; ?></td>
				            <td><?php echo 3000-$total_cost; $_SESSION["value_3000_T"] = 3000-$total_cost;?></td>
				              
				            <td><?php echo $oneyear_cost; ?></td>
				        
				            <td><?php echo 2000-$oneyear_cost; $_SESSION["value_2000_Y"] = 2000-$oneyear_cost;?></td>
				    </table>
										
					<br/><br/><br/><br/>
					</div>
					
					<div class="element col-sm-4  gall  ecosttrip">
						<div class="col-md-9 col-xs-12 forma">
						<h3>Estimated Cost of Trip</h3><br></br>
					
							
							<script type="text/jscript">
  								function calTotal(){
								   	var input1=document.getElementById("v1").value || 0;
								    var input2=document.getElementById("v2").value || 0;
								   	var input3=document.getElementById("v3").value || 0;
								   	var input4=document.getElementById("v4").value || 0;
								   	var input5=document.getElementById("v5").value || 0; 
									
								   	var result = parseFloat(input1)+parseFloat(input2)+parseFloat(input3)+parseFloat(input4)+parseFloat(input5);
									document.getElementById("vtotal").value = result;	
									var minFour = Math.min(result,1250,parseFloat(window.oTable.rows[1].cells[2].innerHTML),parseFloat(window.oTable.rows[1].cells[3].innerHTML));
								//	document.getElementById("minV").value = minTwo;		
									minTable.rows[1].cells[0].innerText = minFour;
							}
							</script>
							
							<table>
							
								<tr>
									<td></td>  
									<td><h4>Calculations and Justification</h4></td>       
									<td style="float:right;"><h4>UK Pound</h4></td>  
								<tr>
									<td><h4>Registration Fee</h4> </td>
									<td><textarea  class="col-md-12 col-xs-12 Calculation" name='rfCal'></textarea></td><td><textarea  id="v1" class="col-md-12 col-xs-12 ECost" onblur="calTotal()" onkeyup="value=value.replace(/[^(\d||/.)]/g,'')"  name='rfECost'></textarea></td>
								<tr>
									<td><h4>Transport costs (provide a breakdown)</h4> </td>
									<td><textarea  class="col-md-12 col-xs-12 Calculation" name='tcCal'></textarea></td> <td><textarea id="v2" class="col-md-12 col-xs-12 ECost" onblur="calTotal();" onkeyup="value=value.replace(/[^(\d||/.)]/g,'')" name='tcECost'></textarea></td>
								<tr>
									<td><h4>Accommodation</h4> </td>
									<td><textarea  class="col-md-12 col-xs-12 Calculation" name='aCal'></textarea></td><td><textarea id="v3" class="col-md-12 col-xs-12 ECost" onblur="calTotal()" onkeyup="value=value.replace(/[^(\d||/.)]/g,'')" name='aECost'></textarea></td>
								<tr>
									<td><h4>Meals</h4> </td>
									<td><textarea  class="col-md-12 col-xs-12 Calculation" name='mCal'></textarea></td><td><textarea id="v4" class="col-md-12 col-xs-12 ECost" onblur="calTotal()" onkeyup="value=value.replace(/[^(\d||/.)]/g,'')" name='mECost'></textarea></td>
								<tr>
									<td><h4>List other items (if any)</h4> </td>
									<td><textarea  class="col-md-12 col-xs-12 Calculation" name='oCal'></textarea></td><td><textarea id="v5" class="col-md-12 col-xs-12 ECost" onblur="calTotal()" onkeyup="value=value.replace(/[^(\d||/.)]/g,'')" name='oECost'></textarea></td>
								<tr>
									<td></td><td></td>
									
									<td><input id="vtotal"  name='totalECost' disabled="disabled" class="col-md-12 col-xs-12 ECost" readonly="readonly" placeholder='TOTAL (E)' /></td>
							</table>
					
						</div>
					</div>
					
					<div class="element col-sm-20  gall maxclaim">

						<div class="col-md-9 col-xs-12 forma">
							<h3>Maximum Allowable Claim</h3><br></br>
							<h4>The maximum you will be able to claim:</h4>
						

				
						    <table style="width:1000px" class="hovertable" id="minTable">
					        <tr>
					    	 	<th>Minimum(E, 1250, 3000-T, 2000-Y)</th>
					        <tr>
					        	
					            <td></td>
					            
					   	 	</table>
								<br/><br/><br/>	
						
						</div>
						
					</div>
			</div>
			
			<div class="cBtn" style="text-align: center; background:#34495e;  bottom:0px;">
				<input type="submit"  name="submit" value="Confirm"  class="buy"/>
			</div>
		
				
			
			
		</div>
			
			
		</div>
    </div>    
    </form>
    </body>
	</html>
