<?php
@session_start();
$security_token = $_SESSION['security_token'] = uniqid(rand());?>

<html>
<head>

<meta charset="UTF-8"> 

<link type="text/css" rel="stylesheet" href="css/appComfirmStyle.css">


<meta charset="UTF-8">


		<!-- hua dong xiao guo (click)></-->
		<script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
		<script src="js/sorting.js" type="text/javascript"></script>
		<script src="js/jquery.isotope.js" type="text/javascript"></script>
	

</head>

<body id="top">
<div id="cv">
<div class="mainDetails">

<div id="name">
<h1>Comfirmation of Your Fund Application</h1>

</div>


<div class="clear"></div>
</div>

<div id="mainArea">
<section>
<article>
<div class="sectionTitle">
<h1>Student Details</h1>
</div>

<div class="sectionContent">
<p>
<?php echo "Student Name:  ".$_SESSION["stuName"];?>
<br></br>
<?php echo "Email:  ".$_SESSION["email"];?>
<br></br>
<?php echo "Date of 1st Registration:  ".$_SESSION["date_fReg"];?>
<br></br>
<?php echo "Months Completed  :".$_SESSION["ptitle"];?>
<br></br>
<?php echo "Fees Paid by:  ".$_SESSION["feePayer"];?>
<br></br>
<?php echo "Fees Last Paid  :".$_SESSION["date_feeLPaid"];?>
</p>
</div>
</article>
<div class="clear"></div>
</section>


<section>
<div class="sectionTitle">
<h1>Trip Details</h1>
</div>
	
<div class="sectionContent">
<article>
<p>
<?php if ($_SESSION["type"]==0){?>
<?php echo "Conference Name:  ".$_SESSION["cName"];?>
<br></br>
<?php echo "Conference URL:  ".$_SESSION["cURL"];?>
<br></br>
<?php echo "City/Country:  ".$_SESSION["city"]." / ".$_SESSION["country"];?>
<br></br>
<?php echo "Paper Title  :".$_SESSION["ptitle"];?>
<br></br>
<?php echo "Authors  :".$_SESSION["authors"];?>
<br></br>
<?php } else{?>
<?php echo "Purpose:  ".$_SESSION["purpose"];}?>


</p>

</article>

</div>
<div class="clear"></div>
</section>

<!-- 
<section>
<div class="sectionTitle">
<h1>Previous Funded Trips</h1>
</div>
	
<div class="sectionContent">
<ul class="sectionContent">
<br></br><br></br><br></br>
</ul>
</div>
<div class="clear"></div>
</section>
 -->

<section>
<div class="sectionTitle">
<h1>Estimated Cost of this Trip</h1>
</div>
	
<div class="sectionContent">
<article>

<p>

<?php echo "Registration Fee:  ".$_SESSION["rfCost"];?>
<br></br>
<?php echo "Transport Costs:  ".$_SESSION["tcCost"];?>
<br></br>
<?php echo "Accomodition:  ".$_SESSION["aCost"];?>
<br></br>
<?php echo "Meals:  ".$_SESSION["mCost"];?>
<br></br>
<?php echo "Other Items:  ".$_SESSION["oCost"];?>
<br></br>
<?php echo "Total (E):  ".$_SESSION["totalECost"];?>
<br></br>
<br></br>

</p>

</article>

</div>
<div class="clear"></div>
</section>


<section>
<div class="sectionTitle">
<h1>Maximized Fund to be Claimed</h1>
<h2>Minimum(E, 1250, 3000-T, 2000-Y)</h2>
</div>
	
<div class="sectionContent">
<article>

<p>
<?php echo "Minimum (  ".$_SESSION["totalECost"]." , 1250 , ".$_SESSION["value_3000_T"]." , ".$_SESSION["value_2000_Y"]." )";?>
<br></br>
<?php echo "= ".min($_SESSION["totalECost"],1250,$_SESSION["value_3000_T"],$_SESSION["value_2000_Y"]);?>
</p>

</article>

</div>
<div class="clear"></div>
<br></br><br></br><br></br>
<input type="button" onclick="<?php echo "<script>alert('You will be back to make some changes.'); history.go(-1);</script>;" ?>" name="back" value="Back" style="float:left"/>


<form method="post" action="dbOperation.php">
<button type="submit" name="submit" style="float:right;bottom:0">Confirm</button>
</form>
<br></br><br></br><br></br>

</section>


</div>
</div>

</body>
</html>