<?php
@session_start();
$security_token = $_SESSION['security_token'] = uniqid(rand());

$rfCal = $_POST['rfCal'];
$tcCal = $_POST['tcCal'];
$accCal = $_POST['accCal'];
$mealCal = $_POST['mealCal'];
$otherCal = $_POST['otherCal'];

$rf = $_POST['rf'];
$tc = $_POST['tc'];
$acc = $_POST['acc'];
$meal = $_POST['meal'];
$other = $_POST['other'];
$tripID =  $_SESSION["TripID"];

if(!is_numeric($rf)||!is_numeric($tc)||!is_numeric($acc)|| !is_numeric($meal)||!is_numeric($other)) {
	echo "<script>alert('Please ensure all cost inputs are numbers.'); history.go(-1);</script>";
}
else{

	$total = $rf+$tc+$acc+$meal+$other;
	$conn = new mysqli('mysql5006.smarterasp.net', 'a117c6_phd', 'phd12345', 'db_a117c6_phd');
	$costSql = "UPDATE ecost SET RegFeeCal = '".$rfCal."' ,RegFee = ".$rf." ,TransFeeCal = '".$tcCal."' ,TransFee = ".$tc.
	",AccFeeCal = '".$accCal."' ,AccFee = ".$acc.",MealFeeCal = '".$mealCal."' ,MealFee = ".$meal.
	",OtherFeeCal = '".$otherCal."' ,OtherFee = ".$other.",TotalECost = ".$total.
	" WHERE TripId = ".$tripID;
	$costResult = $conn->query($costSql);
	$conn->close();

	echo "<script>alert('Your application details has been successfully updated !'); window.location='editApplication.php';</script>";

}

?>