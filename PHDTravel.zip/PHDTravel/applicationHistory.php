<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <title> Application History </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The styles -->
    <link id="bs-css" href="css/bootstrap-cerulean.min.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script src='js/jquery.dataTables.min.js'></script>

</head>

<?php include("mainPage.html");
@session_start();
$security_token = $_SESSION['security_token'] = uniqid(rand());
$conn = new mysqli('mysql5006.smarterasp.net', 'a117c6_phd', 'phd12345', 'db_a117c6_phd');

//$StundentID = $_SESSION["StudentID"];

$sql = "SELECT * FROM trip WHERE  StudentID = '{$_SESSION["stuID"]}' ORDER BY SubmissionDate DESC";
$result = $conn->query($sql);

?>
<body>
<div class="ch-container">
    <div class="row">

        <div id="content" class="col-lg-10 col-sm-10">
            <!-- content starts -->
            <div>
                <ul class="breadcrumb">
                    <li>
                        <a href="mainPage.html">Home</a>
                    </li>
                    <li>
                        <a href="#">Tables</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="box col-md-12">
        <div class="box-inner">
            <div class="box-header well" data-original-title="">
                <h2><i class="glyphicon glyphicon-user"></i>  PHD Application History </h2>
            </div>
            <div class="box-content">
                <table class="table table-striped table-bordered bootstrap-datatable" style="background: white;">
                    <thead>
                    <tr>
                        <th>Number</th>
                        <th>Date</th>
                        <th>ConferenceName</th>
                        <th>Other Purpose</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php
                        $last_date;

                        if ($result->num_rows > 0) {
                            $row_num = 0;
                            while($row = $result->fetch_assoc()) {
                                $row_num ++;
                                echo "<tr><td class=\"center\">".$row_num ."</td><td class=\"center\">".$row["SubmissionDate"]."</td><td class=\"center\">".$row["ConferenceName"]."</td><td class=\"center\">".$row["Purpose"]."</td>";

                                switch ($row["Status"]){
                                    case 1:    echo "<td><span class=\"label-primary label label-default\">unapproved by supervisor or tutor</span></td>";break;
                                    case 2:    echo "<td><span class=\"label-warning label label-default\">approved by supervisor, waiting for tutor</span></td>";break;
                                    case 3:    echo "<td><span class=\"label-success label label-default\">approved by both supervisor and tutor</span></td>";break;
                                    case 4:    echo "<td><span class=\"label-danger label label-default\">rejected by supervisor or tutor</span></td>";
                                }

                                if($row["Status"] == 1 ){
                                    echo "<td> <form action='editApplication.php' method=\"post\">
                                                                    <input type=\"hidden\" name=\"TripID\" value=\"".$row["TripID"]."\">
                                                                    <input type=\"submit\" name=\"Edit\" value=\" Edit\" class=\"btn btn-success\"/>
                                                </form></td></tr>";
                                }else{
                                    echo "<td> Cannot edit application in current status </td>";
                                }
                                /*<a class="btn btn-info" href="#">
                               // <i class="glyphicon glyphicon-edit icon-white"></i>
                                //    Edit
                                //</a>
                               // <a class="btn btn-danger" href="#">
                                //<i class="glyphicon glyphicon-trash icon-white"></i>
                               //     Delete
                               // </a>*/

                            }
                        } else {
                            echo "0";
                        }
                        $conn->close();
                        ?>

                        <script>
                            function asd(){
                                $_SESSION['tripId'] = document.getElementById("Edit").value;
                                document.write(alert( $_SESSION['tripId']));
                            }
                        </script>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
</body>
<!--
<form method="post" action="preTripTable.php">
    <table border=1>
        <tr>
            <td width="5%"></td>
            <td width="20%">ConferenceName</td>
            <td width="25%">PaperTitle</td>
            <td width="50%">Status</td>

            <?php
/*            $last_date;

            if ($result->num_rows > 0) {
                $row_num = 0;
                while($row = $result->fetch_assoc()) {
                    $row_num ++;
                    echo "<tr><td>".$row_num ."</td><td>".$row["ConferenceName"]."</td><td>".$row["PaperTitle"]."</td>";

                    switch ($row["Status"]){
                        case 1:    echo "<td>unapproved by supervisor or tutor</td>";break;
                        case 2:    echo "<td>approved by supervisor, waiting for tutor</td>";break;
                        case 3:    echo "<td>approved by both supervisor and tutor</td>";break;
                        case 4:    echo "<td>rejected by supervisor or tutor</td>";
                    }
                }
            } else {
                echo "0";
            }
            $conn->close();
            */?>
-->
    </table>
    <br/><br/>
</form>

</html>

</html>