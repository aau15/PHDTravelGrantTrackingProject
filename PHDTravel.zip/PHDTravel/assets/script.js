
$(document).ready(function() {


	$('body').videoBG({
		position:"fixed",
		zIndex:0,
		mp4:'assets/PHD.mp4',
		ogv:'assets/PHD.ogv',
		webm:'assets/PHD.webm',
		poster:'assets/Tokyo.jpg',
		opacity:0.9,
		loop:true,
		scale:true,
//		height:770,
//		position:"absolute"
		
	});
	
	$('#feature').videoBG({
		position:"fixed",
		zIndex:0,
		mp4:'assets/BackGroundVideo.mp4',
		ogv:'assets/BackGroundVideo.ogv',
		webm:'assets/BackGroundVideo.webm',
		poster:'assets/MountainBike.jpg',
		opacity:0.8,
	});
	
	
	
	$('#div_demo').videoBG({
		mp4:'assets/MountainBike.mp4',
		ogv:'assets/MountainBike.ogv',
		webm:'assets/MountainBike.webm',
		poster:'assets/MountainBike.jpg',
		scale:true,
		zIndex:0
	});
	
	
	$('#text_replacement_demo').videoBG({
		mp4:'assets/text_replacement.mp4',
		ogv:'assets/text_replacement.ogv',
		webm:'assets/text_replacement.webm',
		poster:'assets/text_replacement.png',
		textReplacement:true,
		width:760,
		height:24
	});
		
})