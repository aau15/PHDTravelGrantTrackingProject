﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SupervisorNew1.Models
{
    public class AllPreviews
    {
        public List<ApplicationPreview> previewList { get; set; } 
    }
    public class ApplicationPreview
    {
        public string tripID;
        public string studentName;
        public string conferenceName;
        public string cityCountry;
        public string travelDate;
        public string endDate;
        public string cost;

    }
}