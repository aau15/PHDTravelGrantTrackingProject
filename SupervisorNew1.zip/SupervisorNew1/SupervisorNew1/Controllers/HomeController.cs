﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using SupervisorNew1.Security;
using SupervisorNew1.Models;

namespace SupervisorNew1.Controllers
{

   
    public class HomeController : Controller
    {
        
        public ActionResult Index()
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login"); 
            }
            return View();
        }

        public ActionResult FlotCharts()
        {
              if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login");              
            }
            return View("FlotCharts");
        }

        public ActionResult MorrisCharts()
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login"); 
            }
            return View("MorrisCharts");
        }

        public ActionResult Tables() // review application 
        {
            if (Session["LoginData"] == null) //check login
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login"); 
            }
            LoginData lg = (LoginData)(Session["LoginData"]);
            string currentUserName = lg.username;//get user id 
            DataBase data = new DataBase(); //create db instance 
            string sql = "select tripid, name, conferencename, city, country ,traveldate,enddate,costoftrip"
                +" from student join trip on student.studentid = trip.studentid"
                +" where student.supervisorID = '"+currentUserName+"';";
            DataTable  dt = data.RunProcReturn(sql,"table").Tables[0]; //get the needed info related to current user

            AllPreviews aps = new AllPreviews(); //create holder for all application preview
            aps.previewList = new List<ApplicationPreview>();
            for(int i = 0;i<dt.Rows.Count;i++) //put everything to Viewmodel
            {
                ApplicationPreview ap = new ApplicationPreview();
                ap.tripID = dt.Rows[i]["tripid"].ToString();
                ap.studentName = dt.Rows[i]["name"].ToString();
                ap.conferenceName = dt.Rows[i]["conferencename"].ToString();
                ap.cost = dt.Rows[i]["costoftrip"].ToString();
                ap.cityCountry = dt.Rows[i]["city"].ToString() + ", " + dt.Rows[i]["country"].ToString();
                ap.travelDate = dt.Rows[i]["traveldate"].ToString();
                ap.endDate = dt.Rows[i]["enddate"].ToString();
                aps.previewList.Add(ap);
            }

           // data.Close();
           // string studentName = dt.Rows[0]["name"].ToString();
            return View(aps);
        }

        public ActionResult Forms()
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login"); 
            }
            return View("Forms");
        }

        public ActionResult Panels()
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login"); 
            }
            return View("Panels");
        }

        public ActionResult Buttons()
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login"); 
            }
            return View("Buttons");
        }

        public ActionResult Notifications()
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login"); 
            }
            return View("Notifications");
        }

        public ActionResult Typography()
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login"); 
            }
            return View("Typography");
        }

        public ActionResult Icons()
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login"); 
            }
            return View("Icons");
        }

        public ActionResult Grid()
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login"); 
            }
            return View("Grid");
        }

        public ActionResult Blank(string id)
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login");              
            }

            string sql = "select trip.tripid,name, email, maxclaim,student.maxclaim12m,  monthscompleted, dofreg, feepayer, feelpaid, conferencename, conferenceurl, city, country, papertitle, author, purpose," 
            +" status, costoftrip,traveldate,enddate,submissiondate, regfeecal,regfee,transfeecal,transfee,accfeecal,accfee,mealfeecal,mealfee,otherfeecal,otherfee from student join trip on student.studentid = trip.studentid join ecost on trip.tripid = ecost.tripid where trip.tripid ="+id+";";
            DataBase data = new DataBase(); //create db instance 
            DataTable dt = data.RunProcReturn(sql, "table").Tables[0];
            ApplicationDetail ad = new ApplicationDetail();

            ad.tripID = dt.Rows[0]["tripid"].ToString();
            ad.studentName = dt.Rows[0]["name"].ToString();
            ad.email = dt.Rows[0]["email"].ToString();
            ad.totalRemained = dt.Rows[0]["maxclaim"].ToString();
            ad.remained12M = dt.Rows[0]["maxclaim12m"].ToString();
            ad.d1stReg = dt.Rows[0]["dofreg"].ToString();
            ad.feePayer = dt.Rows[0]["feepayer"].ToString();
            ad.feeLPaid = dt.Rows[0]["feelpaid"].ToString();
            ad.conferenceName = dt.Rows[0]["conferencename"].ToString();
            ad.conferenceURL = dt.Rows[0]["conferenceurl"].ToString();
            ad.cityCountry = dt.Rows[0]["city"].ToString() + ", " + dt.Rows[0]["country"].ToString();
            ad.paperTitle = dt.Rows[0]["papertitle"].ToString();
            ad.author = dt.Rows[0]["author"].ToString();
            ad.otherReason = dt.Rows[0]["purpose"].ToString();
            ad.totalFee = dt.Rows[0]["costoftrip"].ToString();
            ad.travelDate = dt.Rows[0]["traveldate"].ToString();
            ad.endDate = dt.Rows[0]["enddate"].ToString();
            ad.dOfSubmission = dt.Rows[0]["submissiondate"].ToString();
            ad.regCal = dt.Rows[0]["regfeecal"].ToString();
            ad.regFee = dt.Rows[0]["regfee"].ToString();
            ad.transCal = dt.Rows[0]["transfeecal"].ToString();
            ad.transFee = dt.Rows[0]["transfee"].ToString();
            ad.accomCal = dt.Rows[0]["accfeecal"].ToString();
            ad.accomFee = dt.Rows[0]["accfee"].ToString();
            ad.mealCal = dt.Rows[0]["mealfeecal"].ToString();
            ad.mealFee = dt.Rows[0]["mealfee"].ToString();
            ad.otherCal = dt.Rows[0]["otherfeecal"].ToString();
            ad.otherFee = dt.Rows[0]["otherfee"].ToString();
            ad.monthsComp = dt.Rows[0]["monthscompleted"].ToString();
            Session["ApplicationDetail"] = ad;
            return View(ad);
        }

        [HttpPost]
        public ActionResult Blank(string tripid, string operation, string maxFundInput, string researchAccInput, string commentInput, FormCollection frm )
        {
            if (Session["LoginData"] == null)
            {
                ViewBag.message = "Please Sign in first";
                return RedirectToAction("Login");
            }
            int applicationStatus = 1;
            int oktoFund = 0;
            if (frm["optionsRadiosInline"] == "option1")
            {
                oktoFund = 1;
            }
            else if (frm["optionsRadiosInline"] == "option2")
            {
                oktoFund = 2;
            }


            if(operation.Equals("approve"))
            {
                applicationStatus = 2;
            }
            else if(operation.Equals("reject"))
            {
                applicationStatus = 4;
            }
            else if(operation.Equals("message"))
            {
                applicationStatus = 1;
            }
                   


            if(!operation.Equals("message") &&oktoFund!=0 )
            {            
                
                if (applicationStatus == 2 && String.IsNullOrEmpty(maxFundInput) && String.IsNullOrEmpty(researchAccInput)) //if approve but required detail not entered
                {
                    ViewBag.message = "Max funding column or research account column can not be empty!";
                    if(Session["ApplicationDetail"]!=null)
                    {
                        ApplicationDetail ad = (ApplicationDetail)Session["ApplicationDetail"];
                        return View(ad);
                    }
                    else
                    return View("Index");
                    
                }
                else if (applicationStatus == 4 && commentInput == " ") //reject but no comment
                {
                    ViewBag.message = "Comment can not be empty!";
                    if (Session["ApplicationDetail"] != null)
                    {
                        ApplicationDetail ad = (ApplicationDetail)Session["ApplicationDetail"];
                        return View(ad);
                    }
                    else 
                    return View("Index");
                }
                else  //tutor approval
                {
                    DataBase data = new DataBase();
                    string sql = "update trip set maxtofund =" + maxFundInput + ",  researchacc='" + researchAccInput + "', status=" + applicationStatus + ", oktofund =" + oktoFund + ", scomment ='" + commentInput + "' where tripid =" + tripid + ";";
                    try
                    {
                        data.RunProc(sql); //update the database 
                        ViewBag.message = "Update record successful";
                    }
                    catch(Exception)
                    {
                        ViewBag.message = "Failed to update record!";
                    }

                }
                   
                
                

            }
            return View("Index");
        }

        public ActionResult Login(string username, string password, FormCollection frm)
        {

            if (Session["LoginData"] != null)
            {
                return View("Index");
            }
            else
            {
                 string name = AuthenticationService.SignIn(username, password, true);
                if (!string.IsNullOrEmpty(name))
                {
                    LoginData lg = new LoginData(username, 1, name); //static data for now
                    Session["LoginData"] = lg; //login data

                    //  string role = HttpContext.Identity.AuthenticationType;

                    return View("Index");
                }
                else
                {
                    return View("Login");
                }

            }

           
        }

        public ActionResult Logout()
        {
            AuthenticationService.SignOut();
            Session["LoginData"] = null;
            return View("Login"); 
        }
    }
}