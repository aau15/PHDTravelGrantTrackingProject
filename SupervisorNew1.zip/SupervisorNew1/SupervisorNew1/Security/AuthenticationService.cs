﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data;

namespace SupervisorNew1.Security
{
    public class AuthenticationService
    {
        public static string SignIn(string userName, string pwd, bool createPersistentCookie)
        {

     //       if (String.IsNullOrEmpty(userName))
      //          throw new ArgumentException("Value cannot be null or empty.", "userName");

            if (userName == "s1234" && pwd == "password") // mock login
            {

              //  Membership.ValidateUser(userName, pwd);
                FormsAuthentication.SetAuthCookie(userName, createPersistentCookie);
                return "sophia"; //static for now

            }
            else
            {
                return null;
            }       
        }

        public static void SignOut()
        {
            FormsAuthentication.SignOut();
        }
    }
}